#pragma once

#ifndef SIMPLE_EXAMPLE_DATA_IO_H
#define SIMPLE_EXAMPLE_DATA_IO_H

char *input();
char *scale_string(char *str);

#endif //SIMPLE_EXAMPLE_DATA_IO_H
